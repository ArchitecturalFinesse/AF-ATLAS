export async function onRequestGet({env,request}) {
  const headers={'Content-Type':'application/json','Cache-Control':'no-store'};
  if (!env.NOTION_API_TOKEN) return new Response(JSON.stringify({ok:false,error:'NOTION_API_TOKEN no configurado'}),{status:503,headers});
  // No exponemos el token ni los datos de Notion en una ruta pública.
  if (!request.headers.get('Cf-Access-Jwt-Assertion')) return new Response(JSON.stringify({ok:false,error:'Protege primero este sitio con Cloudflare Access'}),{status:403,headers});
  try {
    const response=await fetch('https://api.notion.com/v1/users/me',{headers:{Authorization:`Bearer ${env.NOTION_API_TOKEN}`,'Notion-Version':'2022-06-28'}});
    if(!response.ok) return new Response(JSON.stringify({ok:false,error:`Notion respondió ${response.status}. Revisa token y permisos.`}),{status:502,headers});
    return new Response(JSON.stringify({ok:true,service:'AF ATLAS / Notion',mode:'diagnóstico, sin escritura'}),{headers});
  }catch{return new Response(JSON.stringify({ok:false,error:'No se pudo contactar a Notion'}),{status:502,headers});}
}
