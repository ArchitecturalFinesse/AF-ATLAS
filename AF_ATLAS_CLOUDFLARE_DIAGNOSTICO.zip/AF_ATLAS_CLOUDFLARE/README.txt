AF ATLAS 3.3 - PRIMERA FASE DE CONEXIÓN SEGURA

1. Se conserva el archivo ATLAS 3.3 original, agregando un panel de diagnóstico.
2. functions/api/status.js es una Cloudflare Pages Function.
3. Para desplegar funciones, sube el directorio functions al repositorio GitHub conectado a Cloudflare Pages. El HTML debe servirse en el mismo dominio de Cloudflare Pages.
4. En Cloudflare Pages, NOTION_API_TOKEN debe estar configurado como Secret.
5. ANTES de activar la función, configura Cloudflare Access para restringir el dominio de Pages a tu identidad. El endpoint exige el encabezado de Access; no confíes en esto como sustituto de una política Access activa.
6. Prueba el botón Verificar conexión segura. La prueba usa /v1/users/me y no altera datos.
7. Esta entrega NO incluye sincronización real de módulos ni escrituras a Notion; para eso hace falta inspeccionar propiedades de las bases y diseñar mapeos y permisos.
8. NO reemplaces index.html automáticamente: el archivo correcto es AF_ATLAS_3_3_TODO_EN_UNO(1).html.
